<template>
  <Toast />
  <router-view />
</template>

<script setup>
import Toast from 'primevue/toast'
</script>
