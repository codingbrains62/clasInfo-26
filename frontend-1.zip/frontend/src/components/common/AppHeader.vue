<template>
  <div class="header-left">
    <i class="fas fa-bars toggle-btn" @click="$emit('toggleSidebar')"></i>
    <span class="header-title" @click="goDashboard">CLASInfo PRO</span>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()

function goDashboard() {
  router.push('/dashboard')
}
</script>

<style scoped>
.header-left {
  display: flex;
  align-items: center;
  height: 51px;
  background: #003e77;
  padding: 0 15px;
  color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
}
.toggle-btn {
  font-size: 20px;
  cursor: pointer;
}
.header-title {
  margin-left: 10px;
  font-size: 18px;
  cursor: pointer;
}
</style>
