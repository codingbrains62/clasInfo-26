<template>
  <AppHeader @toggleSidebar="toggleSidebar" />

  <AppSidebar
    :open="sidebarOpen"
    @close="sidebarOpen = false"
  />

  <main class="page-content">
    <router-view />
  </main>

  <AppFooter />
</template>

<script setup>
import { ref } from 'vue'

import AppHeader from '@/components/common/AppHeader.vue'
import AppSidebar from '@/components/common/AppSidebar.vue'
import AppFooter from '@/components/common/AppFooter.vue'

const sidebarOpen = ref(false)

function toggleSidebar() {
  sidebarOpen.value = !sidebarOpen.value
}
</script>

<style>
.page-content {
  padding-top: 52px; /* header height */
}
</style>
