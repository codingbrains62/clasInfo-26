<template>
  <div
    :class="['left-sidebar', { open }]"
    @click.self="$emit('close')"
  >
    <div class="sidebar-inner">
      <span class="sidebar-title">What would you like to do?</span>
      <hr />

      <a class="leftnav_btn" @click="go('/dashboard')">
        <i class="fas fa-tachometer-alt"></i> Access Dashboard
      </a>

      <a class="leftnav_btn" @click="go('/placeorder')">
        <i class="fas fa-clipboard-list"></i> Place an Order
      </a>

      <div class="mainPageContact">
        <label>
          Contact us for assistance<br>
          (800) 952-5696<br>
          <a href="mailto:connect@clasinfo.com">connect@clasinfo.com</a>
        </label>
        <img src="@/assets/images/CLASWW.png" class="logoImage" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
const props = defineProps({ open: Boolean })
const router = useRouter()

function go(path) {
  router.push(path)
}
</script>

<style scoped>
.left-sidebar {
  position: fixed;
  top: 51px;
  left: 0;
  width: 0;
  height: 100%;
  background: #f7f7f7;
  transition: width 0.3s;
  overflow-x: hidden;
  z-index: 999;
}
.left-sidebar.open {
  width: 300px;
}
.sidebar-inner {
  padding: 15px;
}
.leftnav_btn {
  display: block;
  padding: 8px;
  cursor: pointer;
}
</style>
