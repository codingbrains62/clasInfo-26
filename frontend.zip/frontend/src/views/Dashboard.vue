<template>
  <div>Dashboard works</div>
</template>
