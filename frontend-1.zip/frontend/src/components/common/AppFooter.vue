<template>
  <footer id="page-footer">
    <div class="footer-left">
      <small class="copy">
       Copyright © 2026 <a href="https://clasinfo.com" target="_blank">CLAS Information Services</a>. All right reserved.
      </small>
    </div>

    <div class="footer-center"></div> <!-- Flexible space -->

    <div class="footer-right">
      <small class="nav">
        <a href="/contact">Contact us</a>
        <a href="/terms">Terms of use</a>
        <a href="/privacypolicy">Privacy policy</a>
      </small>
    </div>
  </footer>
</template>
<style scoped>
#page-footer {
    display: flex;
    justify-content: space-between; /* left | center | right */
    align-items: center;
    width: 100%;
    background: #f8f9fa;
    border-top: 1px solid rgba(0,0,0,0.1);
    position: fixed;
    bottom: 0;
    left: 0;
    padding: 10px 20px;
    font-size: 0.85rem;
    z-index: 100;
    box-sizing: border-box;
}

.footer-left {
    text-align: left;
}

.footer-center {
    flex: 1; /* flexible space */
}

.footer-right {
    text-align: right;
}

.footer-right a {
    margin-left: 20px;
    color: #2196f3;
    text-decoration: none;
    font-weight: 500;
    transition: 0.3s;
}

.footer-right a:hover {
    color: #003e77;
}

.footer-left a {
    color: #2196f3;
    text-decoration: none;
}

.footer-left a:hover {
    color: #003e77;
}
</style>